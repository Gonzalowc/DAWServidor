package org.servidor.uni.models.departamento;

public class DepartamentoDTO {

	private String nombre;

	public DepartamentoDTO() {}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}
